from components.ai import HostileEnemy
from components.consumable import HealingConsumable
from components.equipment import Equipment
from components import equippable
from components.fighter import Fighter
from components.inventory import Inventory
from entity import Actor, Item
import random

names_list = ("Abaddon", "Adramelech", "Ahpuch",
              "Ahriman",
              "Amon",
              "Apollyon",
              "Asmodeus",
              "Astaroth",
              "Azazel",
              "Baalberith",
              "Balaam",
              "Baphomet",
              "Bast",
              "Beelzebub",
              "Behemoth",
              "Bilé",
              "Chemosh",
              "Cimeries",
              "Coyote",
              "Dagon",
              "Damballa",
              "Demogorgon",
              "Diabolus",
              "Dracula",
              "Emma-O",
              "Euronymous",
              "Fenriz",
              "Gorgo",
              "Haborym",
              "Hecate",
              "Ishtar",
              "Kali",
              "Lilith",
              "Loki",
              "Mammon",
              "Mania",
              "Mantus",
              "Marduk",
              "Mastema",
              "Melek Taus",
              "Mephistopheles",
              "Metztli",
              "Mictian",
              "Midgard",
              "Milcom",
              "Moloch",
              "Mormo",
              "Naamah",
              "Nergal",
              "Nihasa",
              "Nija",
              "O‐Yama",
              "Pan",
              "Pluto",
              "Proserpine",
              "Pwcca",
              "Rimmon",
              "Sabazios",
              "Saitan",
              "Sammael",
              "Samnu",
              "Sedit",
              "Sekhmet",
              "Set",
              "Shaitan",
              "Shiva",
              "Supay",
              "T’an‐mo",
              "Tchort",
              "Tezcatlipoca",
              "Thamuz",
              "Thoth",
              "Tunrida",
              "Typhon",
              "Yaotzin",
              "Yen‐lo‐Wang")

player = Actor(
    char="@",
    color=(255, 255, 255),
    name=random.choice(names_list),
    ai_cls=HostileEnemy,
    equipment=Equipment(),
    fighter=Fighter(hp=30, base_defense=2, base_power=5),
    inventory=Inventory(capacity=26),
)

orc = Actor(
    char="☺",
    color=(63, 127, 63),
    name=random.choice(names_list),
    ai_cls=HostileEnemy,
    equipment=Equipment(),
    fighter=Fighter(hp=10, base_defense=0, base_power=3),
    inventory=Inventory(capacity=0),
)
troll = Actor(
    char="☻",
    color=(0, 127, 0),
    name=random.choice(names_list),
    ai_cls=HostileEnemy,
    equipment=Equipment(),
    fighter=Fighter(hp=16, base_defense=1, base_power=5),
    inventory=Inventory(capacity=0),
)  # make another hostile
monster = Actor(
    char="Ω",
    color=(148, 0, 211),
    name="Monster",
    ai_cls=HostileEnemy,
    equipment=Equipment(),
    fighter=Fighter(hp=13, base_defense=2, base_power=4),
    inventory=Inventory(capacity=0),
)
boss = Actor(
    char="&"+"&"+"&"+"\n"+"&"+"&"+"&"+"\n"+"&"+"&"+"&",
    color=(128, 0, 0),
    name="Asmodeus",
    ai_cls=HostileEnemy,
    equipment=Equipment(),
    fighter=Fighter(hp=20, base_defense=3, base_power=4),
    inventory=Inventory(capacity=0),
)

health_potion = Item(
    char="α",
    color=(139, 69, 19),
    name="Hot wings",
    consumable=HealingConsumable(amount=4),
)

Tomahawk = Item(
    char="æ", color=(255, 191, 255), name="Tomahawk", equippable=equippable.Tomahawk()
)

Battleaxe = Item(char="æ", color=(0, 191, 255), name="Battle Axe", equippable=equippable.Battleaxe())

leather_armor = Item(
    char="♫",
    color=(139, 69, 19),
    name="Leather Armor",
    equippable=equippable.LeatherArmor(),
)

chain_mail = Item(
    char="♫", color=(192, 192, 192), name="Chain Mail", equippable=equippable.ChainMail()
)
